@extends('admin.master')
@section('admincontent')
    
        
         <div align="center"><h2>{{$message}}</h2></div>
@stop

   

 