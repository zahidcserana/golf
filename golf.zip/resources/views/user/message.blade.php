@extends('user.master')
@section('content')
    
        
         <div align="center"><h4>{{$message}}</h4></div>
@stop

   

 