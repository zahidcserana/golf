@extends('user.master')
@section('content')
<?php
  $asset = asset('/');
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Golf</title>
	</head>
	<body>
		<center><h1>Golf</h1></center>
		
	</body>
</html>
@stop