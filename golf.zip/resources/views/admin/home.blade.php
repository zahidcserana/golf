@extends('admin.master')
@section('admincontent')
<div align="center">
	<h2>Welcome in our play ground</h2>
</div>
@stop