<?php $__env->startSection('content'); ?>
    
        
         <div align="center"><h4><?php echo e($message); ?></h4></div>
<?php $__env->stopSection(); ?>

   

 
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>