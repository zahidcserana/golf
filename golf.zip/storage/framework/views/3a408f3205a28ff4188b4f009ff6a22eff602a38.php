<?php $__env->startSection('content'); ?>
<?php
  $asset = asset('/');
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Golf</title>
	</head>
	<body>
		<center><h1>Golf</h1></center>
		
	</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>