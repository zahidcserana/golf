<?php $__env->startSection('admincontent'); ?>
<br /><br />
	<?php if(Session::has('message')): ?>
		<p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
	<?php endif; ?>
	<table class="table">
		<thead>
			<th>ID</th>
			<th>NAME</th>
			<th>EMAIL</th>
			<th>USER TYPE</th>
			<th>ACTION</th>
			
		</thead>
		<?php foreach($users as $user): ?>
		<tr>
		  <td><?php echo e($user->id); ?> </td>
		  <td><?php echo e($user->name); ?> </td>
		  <td><?php echo e($user->email); ?> </td>
		  <td><?php echo e($user->user_type); ?> </td>
		  <td><a href="<?php echo e(route('password_change',['id'=>$user->id, 'email'=>$user->email])); ?>">change password</a>
		  <?php if($user->user_type == 'user'): ?>
		   	| <a href="<?php echo e(route('make_admin', ['id'=>$user->id, 'email'=>$user->email])); ?>" title="make admin" onclick="return MakeAdmin();">upgrade to admin</a>
		  <?php endif; ?>
		  <?php if($user->user_type == 'admin'): ?>
		  	| <a href="<?php echo e(route('downgrade_to_user',['id'=>$user->id, 'email'=>$user->email])); ?>"  title="downgrade" onclick="return Downgrade();">downgrade to user</a> 
		 <?php endif; ?>
		 | <a href="<?php echo e(route('delete_user',['id'=>$user->id, 'email'=>$user->email])); ?>"  title="delete" onclick="return Delete();">delete</a> </td>
		</tr>
		<?php endforeach; ?>

	</table>
	<?php echo e($users->links()); ?>

<?php $__env->stopSection(); ?>

  	<script type="text/javascript">
            function MakeAdmin()
            {
                var chk=confirm('Do you really want to proceed this action?');
                if(chk)
                {
                    return true;
                }
                else{
                    return false;
                }
            }
            function Downgrade()
            {
                var chk=confirm('Do you really want to proceed this action?');
                if(chk)
                {
                    return true;
                }
                else{
                    return false;
                }
            }
            function Delete()
            {
                var chk=confirm('Do you really want to proceed this action?');
                if(chk)
                {
                    return true;
                }
                else{
                    return false;
                }
            }
	</script>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>