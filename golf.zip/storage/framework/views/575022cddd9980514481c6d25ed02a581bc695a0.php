<?php
  $asset = asset('/');
?>

<?php $__env->startSection('validate'); ?>
@parent
<script src="<?php echo e($asset); ?>js/jquery.min.js"></script>
    <script src="<?php echo e($asset); ?>js/jquery.validate.min.js"></script>
    <script>
    $(document).ready(function() {

        $("#passChange").validate({
            rules: {
                name: "required",
                name: {
                    required: true,
                    minlength: 2
                },
                password: {
                    required: true,
                    minlength: 5
                },
                password_confirmation: {
                    required: true,
                    minlength: 5,
                    equalTo: "#password"
                },
                email: {
                    required: true,
                    email: true
                },
            },
            messages: {
                name: "Please enter your firstname",
                name: {
                    required: "Please enter a username",
                    minlength: "Your username must consist of at least 2 characters"
                },
                password: {
                    required: "Please provide a password",
                    minlength: "Your password must be at least 5 characters long"
                },
                password_confirmation: {
                    required: "Please provide a password",
                    minlength: "Your password must be at least 5 characters long",
                    equalTo: "Please enter the same password as above"
                },
                email: "Please enter a valid email address",
            }
        });

    });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admincontent'); ?>
<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
    <h1 class="page-header">Change Password</h1>
                    
    <form method="POST" id="passChange" action="<?php echo e(url('password_reset')); ?>">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="id" value="<?php echo e($id); ?>">
        <div class="form-group">
            <input type="password" id="password" name="password" class="form-control" placeholder="Enter password">
        </div>
        <div class="form-group">
            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" placeholder="Enter confirm password">
        </div>
        
        <button type="submit" class="btn btn-default">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>